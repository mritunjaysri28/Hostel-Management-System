-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 10, 2016 at 08:34 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hostel`
--

-- --------------------------------------------------------

--
-- Table structure for table `cassess`
--

CREATE TABLE IF NOT EXISTS `cassess` (
  `srno` int(100) NOT NULL AUTO_INCREMENT,
  `uname` varchar(100) NOT NULL,
  `courses` varchar(90) NOT NULL,
  `year` varchar(10) NOT NULL,
  `room` int(50) NOT NULL,
  `computer` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `from` time NOT NULL,
  `fp` varchar(3) NOT NULL,
  `to` time NOT NULL,
  `tp` varchar(3) NOT NULL,
  `remark` varchar(200) NOT NULL,
  PRIMARY KEY (`srno`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `cassess`
--

INSERT INTO `cassess` (`srno`, `uname`, `courses`, `year`, `room`, `computer`, `date`, `from`, `fp`, `to`, `tp`, `remark`) VALUES
(2, 'mritunjay', 'B.Tech(cs)', '2nd YEAR', 408, 'pc 1', '2016-03-22', '23:00:00', '', '23:00:00', '', 'damage');

-- --------------------------------------------------------

--
-- Table structure for table `cdetails`
--

CREATE TABLE IF NOT EXISTS `cdetails` (
  `srno` int(200) NOT NULL AUTO_INCREMENT,
  `device` varchar(30) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(10) NOT NULL,
  `hostel` varchar(100) NOT NULL,
  `located` varchar(40) NOT NULL,
  PRIMARY KEY (`srno`),
  UNIQUE KEY `device` (`device`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `cdetails`
--

INSERT INTO `cdetails` (`srno`, `device`, `date`, `status`, `hostel`, `located`) VALUES
(1, 'pc 1', '2016-03-22', 'not workin', 'boys hostel', '1st floor'),
(8, 'pc 3', '2016-03-22', 'ISSUE', 'BOYS HOSTEL', '2nd FLOOR'),
(12, 'dmf', '2016-03-22', 'WORKING', 'BOYS HOSTEL', 'NH(GROUND FLOOR');

-- --------------------------------------------------------

--
-- Table structure for table `dvisit`
--

CREATE TABLE IF NOT EXISTS `dvisit` (
  `doctorname` varchar(50) NOT NULL,
  `visitdate` date NOT NULL,
  `remark` varchar(500) NOT NULL,
  PRIMARY KEY (`visitdate`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dvisit`
--

INSERT INTO `dvisit` (`doctorname`, `visitdate`, `remark`) VALUES
('Dr. Azhar Udiu', '2015-12-29', 'NOT CAME');

-- --------------------------------------------------------

--
-- Table structure for table `mdetails`
--

CREATE TABLE IF NOT EXISTS `mdetails` (
  `medicinename` varchar(400) NOT NULL,
  `maxstock` int(100) NOT NULL,
  `avilablestock` int(100) NOT NULL,
  `used` varchar(500) NOT NULL,
  PRIMARY KEY (`medicinename`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mdetails`
--

INSERT INTO `mdetails` (`medicinename`, `maxstock`, `avilablestock`, `used`) VALUES
('COMBIFLAME', 600, 260, 'fhsdfjh');

-- --------------------------------------------------------

--
-- Table structure for table `mprovided`
--

CREATE TABLE IF NOT EXISTS `mprovided` (
  `srno` int(3) NOT NULL AUTO_INCREMENT,
  `pdate` date NOT NULL,
  `sname` varchar(30) NOT NULL,
  `room` int(5) NOT NULL,
  `courses` varchar(10) NOT NULL,
  `year` int(1) NOT NULL,
  `mname` varchar(20) NOT NULL,
  `quantity` int(2) NOT NULL,
  `reason` varchar(40) NOT NULL,
  PRIMARY KEY (`srno`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `mprovided`
--

INSERT INTO `mprovided` (`srno`, `pdate`, `sname`, `room`, `courses`, `year`, `mname`, `quantity`, `reason`) VALUES
(1, '2016-03-15', 'MRITUNJAY SRIVASTAVA', 408, 'B.Tech(cs)', 2, 'disprin', 1, 'not known'),
(3, '2013-06-05', 'mritunjay srivastava', 408, 'B.Tech(cs)', 2, 'PARACETAMOLE', 1, 'not known');

-- --------------------------------------------------------

--
-- Table structure for table `nmatten`
--

CREATE TABLE IF NOT EXISTS `nmatten` (
  `nmname` varchar(200) NOT NULL,
  `day` int(10) NOT NULL,
  `mon` int(10) NOT NULL,
  `year` int(10) NOT NULL,
  `status` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nmatten`
--

INSERT INTO `nmatten` (`nmname`, `day`, `mon`, `year`, `status`) VALUES
('toi', 22, 12, 2016, 'came'),
('DANIK JAGRAN', 23, 11, 2015, 'R'),
('DANIK JAGRAN', 22, 3, 2016, 'R'),
('DANIK JAGRAN', 12, 1, 2016, 'R'),
('DANIK JAGRAN', 20, 3, 2016, 'R');

-- --------------------------------------------------------

--
-- Table structure for table `nmdetails`
--

CREATE TABLE IF NOT EXISTS `nmdetails` (
  `nmname` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `doj` date NOT NULL,
  `cost` int(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nmdetails`
--

INSERT INTO `nmdetails` (`nmname`, `type`, `doj`, `cost`) VALUES
('DANIK JAGRAN', 'NEWSPAPER', '2016-03-25', 200),
('HINDUSTAN', 'NEWSPAPER', '2016-01-02', 200),
('dhfjdls', 'newspaper', '2016-03-18', 500),
('toi', 'NEWSPAPER', '2016-03-25', 200),
('AMAR UJALA', 'NEWSPAPER', '2013-06-05', 240);

-- --------------------------------------------------------

--
-- Table structure for table `notice`
--

CREATE TABLE IF NOT EXISTS `notice` (
  `loginid` varchar(30) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `notice` varchar(900) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notice`
--

INSERT INTO `notice` (`loginid`, `subject`, `notice`) VALUES
('admin', 'lfkdl', 'Extra class of 1st year student who got back in even semester.'),
('admin', 'dsfj', 'Fees must be paied before 12 APRIL 2016'),
('admin', 'text', 'No student will be allowed to bunk the class in college timming'),
('ergdvrbrtg', 'gttesrvrd', 'All the students of the hostel are hereby informed that they need to follow the rules and regulations of hostel and sign the attendance regularly; otherwise administrative action will be taken against the defaulters.   '),
('uhfyfyfgyyf', 'hd8tugeld', 'Everyone is requested to make sure that our campus is neat & clean Rs500 will be imposed if any spiting of Pan-masala is found anywhere in college premises & hostel.');

-- --------------------------------------------------------

--
-- Table structure for table `studetails`
--

CREATE TABLE IF NOT EXISTS `studetails` (
  `name` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `fname` varchar(100) NOT NULL,
  `fcontact` int(10) NOT NULL,
  `mname` varchar(100) NOT NULL,
  `mcontact` int(10) NOT NULL,
  `tadd` varchar(600) NOT NULL,
  `padd` varchar(600) NOT NULL,
  `courses` varchar(100) NOT NULL,
  `year` varchar(100) NOT NULL,
  `doj` date NOT NULL,
  `emailid` varchar(100) NOT NULL,
  `scontact` int(10) NOT NULL,
  `enum` int(10) NOT NULL,
  `hostel` varchar(100) NOT NULL,
  `room` int(100) NOT NULL,
  `login` varchar(500) NOT NULL,
  `pass` varchar(500) NOT NULL,
  `photo` varchar(1000) NOT NULL,
  UNIQUE KEY `fcontact` (`fcontact`),
  UNIQUE KEY `mcontact` (`mcontact`),
  UNIQUE KEY `emailid` (`emailid`),
  UNIQUE KEY `scontact` (`scontact`),
  UNIQUE KEY `enum` (`enum`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `studetails`
--

INSERT INTO `studetails` (`name`, `dob`, `fname`, `fcontact`, `mname`, `mcontact`, `tadd`, `padd`, `courses`, `year`, `doj`, `emailid`, `scontact`, `enum`, `hostel`, `room`, `login`, `pass`, `photo`) VALUES
('sdhf', '2016-03-17', 'sdf', 2147483647, 'dskjfh', 987654321, 'sdjkf', 'sdjfh', 'sdj', 'sdfj', '2016-03-17', 'sldkjf', 1234567890, 2134567890, 'sldkjf', 89, 'po', 'po', 'ksldjf');

-- --------------------------------------------------------

--
-- Table structure for table `user_data`
--

CREATE TABLE IF NOT EXISTS `user_data` (
  `srno` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `password` varchar(100) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `post` varchar(100) NOT NULL,
  `id` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `propic` varchar(200) NOT NULL,
  `department` varchar(100) NOT NULL,
  PRIMARY KEY (`srno`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `user_data`
--

INSERT INTO `user_data` (`srno`, `name`, `password`, `phone`, `post`, `id`, `email`, `propic`, `department`) VALUES
(1, 'rajneesh kumar', 'rajneesh', 9935622419, 'php trainer', 'raj622419', 'sumrajneesh622419@gmail.com', '', 'medical'),
(2, 'Mritunjay srivastava', '223227', 9867542651, 'Admin', 'ainain', 'azmi@gmail.com', '', 'networking');
